fruit = ["pear", "dragonfruit", "fig", "clementine"]

puts fruit.count { |ele| ele.length > 5 }